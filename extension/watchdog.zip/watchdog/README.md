To setup:

1. Install relevant dependencies with `yarn install` on root directory.
2. Place your OpenAI api key in the apiKey object (mine is rate limited) inside `config.js`.
3. Build with `npx webpack --mode production` before loading the folder into Chrome.

- Bob
